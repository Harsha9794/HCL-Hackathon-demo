export class Products{
    id: number;
    productName: string;
    productDesc: string;
    quantity: string;
    rate: string;
}

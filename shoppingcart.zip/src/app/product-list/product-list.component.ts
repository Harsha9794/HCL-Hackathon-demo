import { Component, OnInit } from '@angular/core';
import {ProductListServiceService } from '../product-list-service.service';
import {Products} from '../product.model';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

  products: Products[];
  quantity: number;

  constructor(private productlistService: ProductListServiceService) { }

  ngOnInit(): void {
    this.productlistService.getProducts().subscribe(data => {
    this.products = data;
    });
  }

  addtocart(prod: any){
    console.log(prod);
    this.productlistService.addProducttocart(prod).subscribe(data =>{
      console.log(data);
    });
  }

}

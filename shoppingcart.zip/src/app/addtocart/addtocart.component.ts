import { Component, OnInit } from '@angular/core';
import { ProductListServiceService } from '../product-list-service.service';
import { Products } from '../product.model';

@Component({
  selector: 'app-addtocart',
  templateUrl: './addtocart.component.html',
  styleUrls: ['./addtocart.component.css']
})
export class AddtocartComponent implements OnInit {

addedProducts: Products[];

  constructor(private productlistService: ProductListServiceService ) { }

  ngOnInit(): void {
    this.productlistService.getAddedProducts().subscribe(data =>{
    this.addedProducts = data;
    });
  }

}

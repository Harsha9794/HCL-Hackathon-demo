import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import {Products} from './product.model';

@Injectable({
  providedIn: 'root'
})
export class ProductListServiceService {

  private baseUrl = 'http://localhost:8080';
  product: Products[];
  constructor(private httpClient: HttpClient) { }

  getProducts(): Observable<any>{
    return this.httpClient.get<Products>('https://my-json-server.typicode.com/Harsha9794/Hackathon/products');
  }

  addProducttocart(product: any): Observable<any>{
  
    console.log('product' + JSON.stringify(product));
    return this.httpClient.post<any>(this.baseUrl + '/addProductToCart', product);
  }

  getAddedProducts(): Observable<any>{
    return this.httpClient.get<Products>(this.baseUrl + '/getAddedproducts');
  }
}
